//Programmer:	Josh Hallfrisch
//Date:			4/22/2021
//Assignment:	Group Project
//Description:	Header file for map tiles
#pragma once

#include<iostream>	//allows for input and output
#include<string>	//allows for more than one character
#include<iomanip>	//allows formatting/displaying numbers


using namespace std;

class MapTile
{
public:
	//Overloaded functions
	MapTile();
	MapTile(char displayChar);
	MapTile(char displayChar, int formattingCode);
	MapTile(char displayChar, int formattingCode, bool Pathable);

	//10 functions
	char getDisplayChar();
	void setDisplayChar(char);
	int getFormattingCode();
	void setFormattingCode(int);
	string getText();
	void setText(string);
	bool isPortal();
	void setPortal(bool);
	bool isPathable();
	void setPathable(bool);
private:
	//5 data members
	char displayChar;		//The character the tile will be represented as
	int formattingCode;		//The formatting code this tile should use
	string Text;			//This text will display when the player stands on the tile
	bool Portal;			//true if the tile acts as a portal
	bool Pathable;			//true if the player can walk on this tile.  player if the tile blocks movement
							//defaults to true if the character is ' ', false otherwise
							//a ' ' tile could be set to false creating an invisible wall
};