//Programmer:	Tyler Williams
//Date:			4/22/2021
//Assignment:	Group Project
//Description:	Header file for the Item class
//Note:			All code was written by Tyler Williams unless commented otherwise
#include <iostream>
#include "ItemClass.h"
#include <fstream> // file
#include <string>
#include <cstdlib>
#include <time.h> // time
#include <stdlib.h> // srand & rand

using namespace std;

void item::setAttributeEffect(int health, int attack)
{
    healthChange = health;
    attackChange = attack;
}

int item::getHealthChange() {
    return healthChange;
}

int item::getAttackChange() {
    return attackChange;
}

string item::getMessage() {
    return message;
}

void item::itemExtract(string filename) {
    ifstream inFile;
    string line;

    healthChange = 0;
    attackChange = 0;

    inFile.open(filename); //Reads an input file based on the string provided
    if (inFile.is_open())
    {
        
        getline(inFile, line);

        itemType = line.at(0);

        if (line.at(0) == 'H') {
            getline(inFile, line);
            healthChange = stoi(line);  //3rd string operation - converts numbers read as strings from the text file to integers - Jeremiah
        }
        else if (line.at(0) == 'A'){
            getline(inFile, line);
            attackChange = stoi(line);
        }

        getline(inFile, message);
        
        inFile.close();
    }
}

item::item() {
    healthChange = 0;
    attackChange = 0;
    column = 0;
    row = 0;
    message = " ";
    usable = true;
}