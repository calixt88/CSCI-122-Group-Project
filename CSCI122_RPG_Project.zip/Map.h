//Programmer:	Josh Hallfrisch
//Date:			4/22/2021
//Assignment:	Group Project
//Description:	Header file for the Map class
#pragma once

#include<iostream>	//allows for input and output
#include<string>	//allows for more than one character
#include<iomanip>	//allows formatting/displaying numbers
#include "MapTile.h"
#include "character.h"

//using namespace std;

; class Map
{
public:
	Map(int WidthInput, int LengthInput);

	~Map();

	//13 functions
	//2 examples of function overload
	void setEdge(MapTile Wall);
	void setEdge(char WallChar);
	void randomFill(MapTile Wall, double Probability);//Probability is probability that any tile is replaced with Wall
	void randomFill(char WallChar, double Probability);

	MapTile &operator() (int, int);

	void printMap(character player, character* enemies, item* inventory);
	void ProcessMove(character *player, character* enemies, item* inventory);
	int getWidth();
	int getLength();
	bool isEmpty(int column, int row);

	void saveMap(string FileName);
	Map(string FileName);//loads from a file

private:

	//3 data members
	MapTile** MapPtr;  //pointer to MapTile array 
	int Width;
	int Length;
};
