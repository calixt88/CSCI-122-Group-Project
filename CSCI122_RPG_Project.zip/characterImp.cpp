//Programmer:  Calixt Charlebois
//Due date:    04/23/2021
//Assignment:  Group Project
//Description: Character implementation file
//Note:			All code was written by Calixt Charlebois unless commented otherwise


#include <iostream>
#include <string>
#include "character.h"


using namespace std;

//Attacking function
int character::attack(character *enemy)
{
    {
        randomNumber = rand() % 100;        //gives a random number 0-99
        if (randomNumber <= 15)             //if the number is 20 or less, the player will critical strike;
        {
            criticalStrike(enemy);
        }
        else
        {
            enemy->health = enemy->health - attackDmg;
        }
        if (enemy->health < 0) {
            enemy->health = 0;
        }
    }
    return enemy->health;
}

//Function that will manipulate players health (taking dmg)
int character::takeDamage(int health, int enemyAttackDmg)
{
    health = health - enemyAttackDmg;
    return health;
}

//Critical strike function
void character::criticalStrike(character *enemy)
{
    critDmg = attackDmg * 1.5;
    enemy->health = enemy->health - critDmg;
	
}

//This sets the attack and health based on what the player chose for their class
void character::setStats()
{
	switch (characterType) {					
	case 'I':
		switch (playerCharacterType) {
		case 'I':
			attackDmg = STANDARD_DAMAGE;
			health = STANDARD_HEALTH;
			break;
		case 'C':
			attackDmg = WEAK_DAMAGE;
			health = WEAK_HEALTH;
			break;
		case 'P':
			attackDmg = STRONG_DAMAGE;
			health = STRONG_HEALTH;
			break;
		}
		break;
	case 'C':
		switch (playerCharacterType) {
		case 'I':
			attackDmg = STRONG_DAMAGE;
			health = STRONG_HEALTH;
			break;
		case 'C':
			attackDmg = STANDARD_DAMAGE;
			health = STANDARD_HEALTH;
			break;
		case 'P':
			attackDmg = WEAK_DAMAGE;
			health = WEAK_HEALTH;
			break;
		}
		break;
	case 'P':
		switch (playerCharacterType) {
		case 'I':
			attackDmg = WEAK_DAMAGE;
			health = WEAK_HEALTH;
			break;
		case 'C':
			attackDmg = STRONG_DAMAGE;
			health = STRONG_HEALTH;
			break;
		case 'P':
			attackDmg = STANDARD_DAMAGE;
			health = STANDARD_HEALTH;
			break;
		}
		break;
	}
}