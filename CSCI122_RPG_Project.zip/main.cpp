/*
Programmer:  Jeremiah Clifford
Due date:    04/23/2021
Assignment:  Group Project
Description: RPG main file
*/

#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <time.h>
#include <stdlib.h>
#include "ItemClass.h"
#include "Map.h"
#include "MapTile.h"

#define _WIN32_WINNT 0x0500

#include<Windows.h>

//Function declarations
char mainMenu(); 
void initializeEnemies(character player, character *enemies, Map &Battleground, int width, int length);
void displayStats(character player, character *enemies);
void initializeItems(item* inventory, character* enemies, Map &Battleground, int width, int length);
bool isPlayerAlive(character player);
bool areAnyEnemiesAlive(character* enemies);
bool isEnemyAtLocation(character* enemies, int column, int row);
bool isEnemyAtLocation(character* enemies, int column, int row, int enemyIndex);

//Function definitions - there are 7 total functions, 3 of which are void and 4 are value-returning
char mainMenu() {
	string asterisks = " ";
	char classChoice = ' ';
	string spaces = " ";
	asterisks.assign(40, '*');		//1st String Operation
	spaces.assign(50, ' ');

	cout << asterisks << " CSCI 122 RPG Project Main Menu" << asterisks << endl << endl;
	cout << spaces << "Instructions" << endl << endl;
	cout << "There will be enemies to slay, items to aid in your fight, and portals to move long distances." << endl << endl;
	cout << "Use W (or w) to move up, S (or s) to move down, A (or a) to move left, and D (or d) to move right." << endl << endl;
	cout << "You must move onto a tile containing an item or portal to use it, and onto a tile with an enemy to fight them." << endl << endl;
	cout << "When selecting your class, keep in mind:" << endl;
	cout << "Infantry are strong against Pikes, Pikes are strong against Cavalry, and Cavalry are strong against Infantry" << endl << endl;
	cout << "Choose your fighting class. I for Infantry, P for Pike, C for Cavalry. Enter Q to quit the game." << endl;
	cin >> classChoice;
	switch (classChoice) {			//1st Switch Case
	case 'i':
		classChoice = 'I';
		break;
	case 'c':
		classChoice = 'C';
		break;
	case 'p':
		classChoice = 'P';
		break;
	case 'q':
		classChoice = 'Q';
	}
	return classChoice;
}
//This function takes both variables passed by value and by reference, as well as an array
void initializeEnemies(character player, character *enemies, Map &Battleground, int width, int length) { 
	int enemyIndex = 0;
	do {												//1st do...while loop
		switch (enemyIndex % 3)							//2nd switch case
		{
		case 0:
			enemies[enemyIndex].characterType = 'I';
			break;
		case 1:
			enemies[enemyIndex].characterType = 'C';
			break;
		case 2:
			enemies[enemyIndex].characterType = 'P';
			break;
		}

		enemies[enemyIndex].playerCharacterType = player.characterType;
		do {											//2nd do...while loop, nested
			enemies[enemyIndex].column = rand() % (width - 2) + 1;
			enemies[enemyIndex].row = rand() % (length - 2) + 1;
		} while (isEnemyAtLocation(enemies, enemies[enemyIndex].column, enemies[enemyIndex].row, enemyIndex)
			|| !Battleground(enemies[enemyIndex].column, enemies[enemyIndex].row).isPathable()
			|| Battleground(enemies[enemyIndex].column, enemies[enemyIndex].row).isPortal()
			|| Battleground(enemies[enemyIndex].column+1, enemies[enemyIndex].row).isPortal()
			|| Battleground(enemies[enemyIndex].column-1, enemies[enemyIndex].row).isPortal()
			|| Battleground(enemies[enemyIndex].column, enemies[enemyIndex].row+1).isPortal()
			|| Battleground(enemies[enemyIndex].column, enemies[enemyIndex].row-1).isPortal()
			);//Added logic to make sure enemies don't spawn on other enemies, an unpathable tile, on a portal, or adjacent to a portal -Josh



		enemies[enemyIndex].setStats();

		enemyIndex++;
	} while (enemyIndex < NUM_ENEMIES);

} //
void displayStats(character player, character* enemies) {
	character temp;
	HANDLE screen = GetStdHandle(STD_OUTPUT_HANDLE);


	//Displays health below the map

	SetConsoleTextAttribute(screen, 10);
	printf("Health: [%c %3d]  ", player.characterType, player.health);		//1st string operation
	SetConsoleTextAttribute(screen, 12);
	for (int i = 0; i < NUM_ENEMIES; i++) {									//1st sort - bubble sort
		for (int j = 0; j < NUM_ENEMIES; j++) {								
			if (enemies[i].health == enemies[j].health) {					//1st If...else
				if (enemies[i].characterType < enemies[j].characterType) {	//2nd if statement
					temp = enemies[j];
					enemies[j] = enemies[i];
					enemies[i] = temp;
				}
			}
			else if (enemies[i].health < enemies[j].health) {
				temp = enemies[j];
				enemies[j] = enemies[i];
				enemies[i] = temp;
			}
		}
	}

	for (int i = 0; i < NUM_ENEMIES; i++) {									//1st for loop
		printf("[%c %3d]  ", enemies[i].characterType, enemies[i].health);
	}
	SetConsoleTextAttribute(screen, 7);
	cout << endl;

	//Displays attack power under the health listings

	SetConsoleTextAttribute(screen, 10);
	printf("Attack: [%c %3d]  ", player.characterType, player.attackDmg);
	SetConsoleTextAttribute(screen, 12);
	for (int i = 0; i < NUM_ENEMIES; i++) {
		for (int j = 0; j < NUM_ENEMIES; j++) {							//2nd sort - bubble sort
			if (enemies[i].health == enemies[j].health) {				//3rd if...else statement
				if (enemies[i].characterType < enemies[j].characterType) {
					temp = enemies[j];
					enemies[j] = enemies[i];
					enemies[i] = temp;
				}
			}
			else if (enemies[i].health < enemies[j].health) {
				temp = enemies[j];
				enemies[j] = enemies[i];
				enemies[i] = temp;
			}
		}
	}

	for (int i = 0; i < NUM_ENEMIES; i++) {								//2nd for loop
		printf("[%c %3d]  ", enemies[i].characterType, enemies[i].attackDmg);
	}
	SetConsoleTextAttribute(screen, 7);
	cout << endl;
}
void initializeItems(item* inventory, character* enemies, Map &Battleground, int width, int length) {
	int itemIndex = 0;
	
	//Randomly chooses between the two item types
	do {
		switch (itemIndex % 2)											//2nd switch case
		{
		case 0:
			inventory[itemIndex].itemExtract("healthPotion.txt");
			break;
		case 1:
			inventory[itemIndex].itemExtract("attackPotion.txt");
			break;
		}

		do {
			inventory[itemIndex].column = rand() % (width - 2) + 1;
			inventory[itemIndex].row = rand() % (length - 2) + 1;
		} while (isEnemyAtLocation(enemies, inventory[itemIndex].column, inventory[itemIndex].row)
			|| !Battleground(inventory[itemIndex].column, inventory[itemIndex].row).isPathable()
			|| Battleground(inventory[itemIndex].column, inventory[itemIndex].row).isPortal()
			);
		//Added logic to make sure items don't spawn on an unpathable tile or on a portal -Josh

		itemIndex++;
	} while (itemIndex < NUM_ITEMS);
}

//The next two functions determin if the game has been won or lost
bool isPlayerAlive(character player) {
	return player.health > 0;
}

bool areAnyEnemiesAlive(character* enemies) {
	for (int i = 0; i < NUM_ENEMIES; i++) {
		if (enemies[i].health > 0) {
			return true;
		}
	}
	return false;
}

//This function is used to determine if we are attacking an enemy and if an enemy can spawn at the map tile
bool isEnemyAtLocation(character* enemies, int column, int row) {
	for (int i = 0; i < NUM_ENEMIES; i++) {
		if (enemies[i].column == column && enemies[i].row == row) {
			return true;
		}
	}

	return false;
}

//added overload of isEnemyAtLocation() so enemies can check for other enemies (and not find themselves) - Josh
bool isEnemyAtLocation(character* enemies, int column, int row, int enemyIndex) {
	for (int i = 0; i < enemyIndex; i++) {
		if (enemies[i].column == column && enemies[i].row == row) {
			return true;
		}
	}

	return false;
}

int main()
{
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r);

	srand(time(NULL));
	character player;
	character enemies[NUM_ENEMIES];		//1st one-dimensional array
	item inventory[NUM_ITEMS];			//2nd one-dimensional array

	HANDLE screen = GetStdHandle(STD_OUTPUT_HANDLE);

	MoveWindow(console, r.left, r.top, 850, 675, TRUE);  //Not a requirement, but I figured out how to force the console into a specific size

	player.column = 5;
	player.row = 5;
	
	do {
		player.characterType = mainMenu();
	} while (player.characterType != 'I' && player.characterType != 'C' && player.characterType != 'P' && player.characterType != 'Q');

	if (player.characterType == 'Q' || player.characterType == 'q') {
		cout << endl << "The CSCI 122 RPG game will now exit. Thanks for playing!" << endl << endl;
		exit( 0 );
	}
	Map Forest("Forest3.txt");							//Loading map template
	initializeEnemies(player, enemies, Forest, Forest.getWidth(), Forest.getLength());
	initializeItems(inventory, enemies, Forest, Forest.getWidth(), Forest.getLength());

	for (int i = 0; i < NUM_ENEMIES; i++) {				//Turns deceased enemies into white 'X's
		MapTile enemy('X');
		enemy.setPathable(true);
		enemy.setText("You're standing on a corpse");
		enemy.setFormattingCode(15);
		Forest(enemies[i].column, enemies[i].row) = enemy;
	}

	for (int i = 0; i < NUM_ITEMS; i++) {				//Turns used items into white 'O's
		MapTile itemTile('O');
		itemTile.setPathable(true);
		itemTile.setText(inventory[i].getMessage());
		itemTile.setFormattingCode(15);
		Forest(inventory[i].column, inventory[i].row) = itemTile;
	}

	MapTile Hint('?');
	Hint.setPathable(true);
	Hint.setText("The beige objects are items. A is for attack boost, H is for health potion. Purple @ are portals.");
	Hint.setFormattingCode(9);

	Forest(5, 5) = Hint;
	Forest.saveMap("SaveGame.txt");									//Output file

	//Executes printMap to display items, enemies, and the player
	while (isPlayerAlive(player) && areAnyEnemiesAlive(enemies))	//1st while loop
	{
		Forest.printMap(player, enemies, inventory);
		displayStats(player, enemies);
		Forest.ProcessMove(&player, enemies, inventory);
	}

	if (isPlayerAlive(player)) {
		Forest.printMap(player, enemies, inventory);
		SetConsoleTextAttribute(screen, 10);
		cout << "You win" << endl;
		SetConsoleTextAttribute(screen, 7);
	}
	else {
		Forest.printMap(player, enemies, inventory);
		SetConsoleTextAttribute(screen, 12);
		cout << "Game over" << endl;
		SetConsoleTextAttribute(screen, 7);
	}

	system("pause");
	return 0;
}