//Programmer:	Josh Hallfrisch
//Date:			4/22/2021
//Assignment:	Group Project
//Description:	Implements the Map class
//Note:			All code was written by Josh Hallfrisch unless commented otherwise

#include<iostream>	//allows for input and output
#include<string>	//allows for more than one character
#include<iomanip>	//allows formatting/displaying numbers
#include<fstream>	//allows reading and writing of files
#include<Windows.h>
#include "MapTile.h"
#include "Map.h"
#include <cassert> 

using namespace std;

; Map::Map(int WidthInput, int LengthInput)
{
	//Exception handling for map size
	try
	{
		if (WidthInput <= 0 || LengthInput <= 0)
			throw "Map width or length is not positive";
	}
	catch (string)
	{
		cout << endl << "Map width and length must be positive." << endl;
		cout << "Width is " + LengthInput << endl;
		cout << "Length is " + LengthInput << endl;
		cout << "This program will terminate.";
		system("pause");
		throw;
	}
	Width = WidthInput;
	Length = LengthInput;
	MapPtr = new MapTile *[Width];			//MapPtr is an array of MapTile pointers of size 'Width'

	for (int i = 0; i < Width; ++i)
	{
		MapPtr[i] = new MapTile[Length];	//Each of those pointers is set to a new MapTile array of size 'Length'
											//This creates a 2-dimensional array
	}
}

Map::~Map()
{
	delete[] MapPtr;
}

void Map::setEdge(MapTile Wall)
{
	for (int i = 0; i < Width; i++)
	{
		MapPtr[i][0] = Wall;
		MapPtr[i][Length - 1] = Wall;
	}
	for (int i = 0; i < Length; i++)
	{
		MapPtr[0][i] = Wall;
		MapPtr[Width - 1][i] = Wall;
	}
}
void Map::setEdge(char WallChar)
{
	MapTile Wall(WallChar);
	setEdge(Wall);
}


void Map::randomFill(MapTile Wall, double Probability)
{
	for (int Column = 1; Column < Width - 1; Column++)
	{
		for (int Row = 1; Row < Length - 1; Row++)
		{
			if (rand()/32767.0 < Probability)
			{
				MapPtr[Column][Row] = Wall;
			}
		}
	}
}
void Map::randomFill(char WallChar, double Probability)
{
	MapTile Wall(WallChar);
	Map::randomFill(Wall, Probability);
}

MapTile& Map::operator() (int Column, int Row)
{
	assert(0 <= Column && Column < Width && 0 <= Row && Row < Length);
	return MapPtr[Column][Row];
}

//Prints the map with player, enemies, and items
void Map::printMap(character player, character *enemies, item* inventory)			//function parameters edited to take in character objects and internal variables changed to match this - Jeremiah
{
	HANDLE screen = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(screen, 7);
	system("cls");
	int FormattingCode = 7;
	string MapString = "";
	char currentEnemy = ' ';
	char currentItem = ' ';

	for (int Column = 0; Column < Width; Column++)
	{
		for (int Row = 0; Row < Length; Row++)
		{
			currentEnemy = ' ';
			currentItem = ' ';

			for (int enemyIndex = 0; enemyIndex < NUM_ENEMIES; enemyIndex++) {
				if (enemies[enemyIndex].row == Row && enemies[enemyIndex].column == Column && enemies[enemyIndex].health > 0) {
					currentEnemy = enemies[enemyIndex].characterType;
				}
			}

			for (int itemIndex = 0; itemIndex < NUM_ITEMS; itemIndex++) {
				if (inventory[itemIndex].row == Row && inventory[itemIndex].column == Column && inventory[itemIndex].usable) {
					currentItem = inventory[itemIndex].itemType;
				}
			}

			if (Row==player.row && Column==player.column)
			{
				if (FormattingCode != 10)
				{
					cout << MapString;
					MapString = "";
					FormattingCode = 10;
					SetConsoleTextAttribute(screen, FormattingCode);
				}
				MapString += '*';								//2nd String operation - Concatenation
			}
			else if (currentEnemy != ' ') {
				if (FormattingCode != 12)
				{
					cout << MapString;
					MapString = "";
					FormattingCode = 12;
					SetConsoleTextAttribute(screen, FormattingCode);
				}
				MapString += currentEnemy;						
			}
			else if (currentItem != ' ') {
				if (FormattingCode != 14)
				{
					cout << MapString;
					MapString = "";
					FormattingCode = 14;
					SetConsoleTextAttribute(screen, FormattingCode);
				}
				MapString += currentItem;

			}
			else
			{
				if (FormattingCode != MapPtr[Column][Row].getFormattingCode())
				{
					cout << MapString;
					MapString = "";
					FormattingCode = MapPtr[Column][Row].getFormattingCode();
					SetConsoleTextAttribute(screen, FormattingCode);
				}
				MapString += MapPtr[Column][Row].getDisplayChar();
			}
		}
		MapString += "\r\n";														//4th string operation - Concatenation
	}
	cout << MapString;
	SetConsoleTextAttribute(screen, 7);
	if (MapPtr[player.column][player.row].getText() != "")
	{
		cout << MapPtr[player.column][player.row].getText() << endl;
	}
}

void Map::ProcessMove(character *player, character* enemies, item* inventory)			//function parameters edited to take in character objects and internal variables changed to match this - Jeremiah
{
	char MoveDirection = ' ';
	cout << "Move direction (WASD) or Q to quit: ";
	cin >> MoveDirection;
	if (MoveDirection == 'W' || MoveDirection == 'w')
	{
		if (MapPtr[player->column - 1][player->row].isPathable())
		{
			player->column--;
		}
	}
	else if (MoveDirection == 'A' || MoveDirection == 'a')
	{
		if (MapPtr[player->column][player->row - 1].isPathable())
		{
			player->row--;
		}
	}
	else if (MoveDirection == 'S' || MoveDirection == 's')
	{
		if (MapPtr[player->column + 1][player->row].isPathable())
		{
			player->column++;
		}
	}
	else if (MoveDirection == 'D' || MoveDirection == 'd')
	{
		if (MapPtr[player->column][player->row + 1].isPathable())
		{
			player->row++;
		}
	}
	else if (MoveDirection == 'Q' || MoveDirection == 'q') {
		cout << endl << "The CSCI 122 RPG game will now exit. Thanks for playing!" << endl << endl;
		exit( 0 );
	}

	if (MapPtr[player->column][player->row].isPortal())
	{
		int i = player->column + 1;
		int j = player->row;
		for (; i != player->column || j != player->row; i++)
		{
			if (i >= Width)
			{
				i = 0;
				j++;
			}
			if (j >= Length)
			{
				j = 0;
			}
			if (MapPtr[i][j].isPortal() == true)
			{
				if (MoveDirection == 'W' || MoveDirection == 'w')
				{
					if (MapPtr[i - 1][j].isPathable())
					{
						player->column = i;
						player->row = j;
						player->column--;
						break;
					}
				}
				else if (MoveDirection == 'A' || MoveDirection == 'a')
				{
					if (MapPtr[i][j - 1].isPathable())
					{
						player->column = i;
						player->row = j;
						player->row--;
						break;
					}
				}
				else if (MoveDirection == 'S' || MoveDirection == 's')
				{
					if (MapPtr[i + 1][j].isPathable())
					{
						player->column = i;
						player->row = j;
						player->column++;
						break;
					}
				}
				else if (MoveDirection == 'D' || MoveDirection == 'd')
				{
					if (MapPtr[i][j + 1].isPathable())
					{
						player->column = i;
						player->row = j;
						player->row++;
						break;
					}
				}
			}
		}
	}
	
	for (int i = 0; i < NUM_ENEMIES; i++) {									//code added to allow for attacking enemies - Jeremiah
		if (player->row == enemies[i].row && player->column == enemies[i].column) {
			if (MoveDirection == 'W' || MoveDirection == 'w')
			{
				if (enemies[i].health > 0)
				{
					player->column++;
				}
			}
			else if (MoveDirection == 'A' || MoveDirection == 'a')
			{
				if (enemies[i].health > 0)
				{
					player->row++;
				}
			}
			else if (MoveDirection == 'S' || MoveDirection == 's')
			{
				if (enemies[i].health > 0)
				{
					player->column--;
				}
			}
			else if (MoveDirection == 'D' || MoveDirection == 'd')
			{
				if (enemies[i].health > 0)
				{
					player->row--;
				}
			}

			player->attack(&enemies[i]);
			if (enemies[i].health > 0) {
				enemies[i].attack(player);
			}
			else {
				enemies[i].attackDmg = 0;
			}
		}
	}

	for (int i = 0; i < NUM_ITEMS; i++) {									//code to use items as the player steps on them - Jeremiah
		if (inventory[i].usable && player->row == inventory[i].row && player->column == inventory[i].column) {
			player->attackDmg += inventory[i].getAttackChange();
			player->health += inventory[i].getHealthChange();
			inventory[i].usable = false;
		}
	}
	
}

//The first line of the file is the map's width, then length, then the default formatting code
//
//Each tile has data stored for its DisplayChar (preceded by \ if needed) and any combination of the following:
//the character's FormattingCode (surrounded by <>),
//the character's Health (surrounded by []),
//the tile's Text (surrounded by "", with \ as the escape character),
//the tile's Pathability (either P for Pathable or W for Wall)
//
//Any missing fields will be filled in with their default
//An example tile is:?"This is a hint"<9>[P]
void Map::saveMap(string FileName)
{
	ofstream outFile;			//output file stream variable
	outFile.open(FileName);		//Opening output file to write map to
	outFile << Width << " " << Length << " 7";

	for (int Column = 0; Column < Width; Column++)
	{
		outFile << endl;
		for (int Row = 0; Row < Length; Row++)
		{
			MapTile outTile = MapPtr[Column][Row];
			if (outTile.getDisplayChar() == '\\' || outTile.getDisplayChar() == ' < ' || outTile.getDisplayChar() == '"' ||
				outTile.getDisplayChar() == 'P' || outTile.getDisplayChar() == 'W' || outTile.getDisplayChar() == 'R')
				outFile << '\\';
			outFile << outTile.getDisplayChar();
			if (outTile.getFormattingCode() != 7)
			{
				outFile << "<" << outTile.getFormattingCode() << ">";
			}
			if (outTile.getText() != "")
			{
				outFile << "\"" << outTile.getText() << "\"";
			}
			if (outTile.isPortal())
			{
				outFile << "R";
			}
			if (outTile.isPathable() && outTile.getDisplayChar() != ' ')
			{
				outFile << "P";
			}
			if (!outTile.isPathable() && outTile.getDisplayChar() == ' ')
			{
				outFile << "W";
			}
		}
	}
	outFile.close();
}
Map::Map(string FileName)
{
	ifstream inFile;				//input file stream variable
	inFile.open(FileName);			//Opening input file
	//More exception handling
	try
	{
		if (!inFile.is_open())
			throw "File not found";
	}
	catch(string)
	{
		cout << endl << "Map file could not be opened.  This program will terminate.";
		system("pause");
		throw;
	}

	try
	{
		inFile >> Width;
		if (!inFile)
			throw "Width could not be read.";
		inFile >> Length;
		if (!inFile)
			throw "Length could not be read.";
		int Format = 7;
		inFile >> Format;
		if (!inFile)
			throw "Format could not be read.";

		if (Width <= 0 || Length <= 0)
			throw "Map width or length is not positive";

		MapPtr = new MapTile *[Width];

		for (int i = 0; i < Width; ++i)
		{
			MapPtr[i] = new MapTile[Length];
		}

		char inChar = ' ';
		string inString = "";

		for (int Column = 0; Column < Width; Column++)
		{
			inFile.get();			//clears the newline character
			for (int Row = 0; Row < Length; Row++)
			{
				inChar = inFile.get();
				//the escape character must be used if the display char is '\', '<', '"', 'P', 'W', 'R'
				if (inChar == '\\')
					inChar = inFile.get();
				MapTile inTile(inChar);
				inTile.setFormattingCode(Format);//the default formatting code for this map

				while (true)										//2nd while loop
				{
					if (!(inFile.peek() == '<' || inFile.peek() == 'R' || inFile.peek() == 'W' || inFile.peek() == 'P' || inFile.peek() == '"'))
						break;
					if (inFile.peek() == '<')
					{
						inString = "";
						inFile.get();//clearing the '<' from the buffer

						//since the formatting code is always an int, the escape char is unneeded
						while ((inChar = inFile.get()) != '>')
						{
							inString += inChar;
						}
						inTile.setFormattingCode(std::stoi(inString));
					}
					if (inFile.peek() == '"')
					{
						inString = "";
						inFile.get();//clearing the '"' from the buffer

						while ((inChar = inFile.get()) != '"')
						{
							if (inChar == '\\')
								inChar = inFile.get();
							inString += inChar;
						}
						inTile.setText(inString);
					}
					if (inFile.peek() == 'W')
					{
						inTile.setPathable(false);
						inFile.get();//remove the 'W' from the buffer
					}
					if (inFile.peek() == 'P')
					{
						inTile.setPathable(true);
						inFile.get();//remove the 'P' from the buffer
					}
					if (inFile.peek() == 'R')
					{
						inTile.setPortal(true);
						inFile.get();//remove the 'R' from the buffer
					}
				}
				MapPtr[Column][Row] = inTile;
			}
		}
		inFile.close();
	}
	catch(string Msg)
	{
		cout << endl << Msg << endl;
		inFile.close();
		delete[] MapPtr;
		throw;
	}

}

int Map::getWidth()
{
	return Width;
}
int Map::getLength()
{
	return Length;
}

bool Map::isEmpty(int row, int column)
{
	if (row < Length && column < Width && row>0 && column>0) {
		return MapPtr[column][row].isPathable();
	}
	else {
		return false;
	}
}