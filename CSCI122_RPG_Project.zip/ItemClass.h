//Tyler Williams

#ifndef ITEMCLASS_H
#define ITEMCLASS_H

#define NUM_ITEMS 5

using namespace std;

class item
{
	public:
		//5 functions
		void setAttributeEffect(int health, int attack);
		int getHealthChange();
		int getAttackChange();
		string getMessage();
		void itemExtract(string filename);

		//4 data members
		int column;
		int row;
		char itemType;
		bool usable = true;

		item();

	private:
		//3 data members
		int healthChange;
		int attackChange;
		string message;
		
};

#endif
