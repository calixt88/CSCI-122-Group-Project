//Programmer:  Calixt Charlebois
//Due date:    04/23/2021
//Assignment:  Group Project
//Description: Character Class header

#include <string>
#include "ItemClass.h"

#define NUM_ENEMIES 9
#define STANDARD_DAMAGE	25
#define STRONG_DAMAGE	38
#define WEAK_DAMAGE		13

#define STANDARD_HEALTH 100
#define STRONG_HEALTH	150
#define WEAK_HEALTH		50

; class character
{
    public:
        //Declaration of variables used in character.h
        //Total of 10 data members
        char characterType = ' ';
        int randomNumber = 1;
        int critDmg = 75;
        int attackDmg = 50;
        int defense = 1;
        int defenseBoost = 1;
        int health = 100;
        int column = 0;
        int row = 0;
        char playerCharacterType = ' ';

        //declaration of functions
        //4 functions
        void criticalStrike(character *enemy);
        void setStats();
        int takeDamage(int health, int enemyAttackDmg);
        int attack(character *enemy);
        
};

