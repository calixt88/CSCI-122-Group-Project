//Programmer:	Josh Hallfrisch
//Date:			4/22/2021
//Assignment:	Group Project
//Description:	Implements map tiles


#include<iostream>	//allows for input and output
#include<string>	//allows for more than one character
#include<iomanip>	//allows formatting/displaying numbers
#include "MapTile.h"
#include "character.h"

//using namespace std;
//MapTile is a character array and is two-dimensional
MapTile::MapTile()
{
	displayChar = ' ';
	Text = "";
	formattingCode = 7;
	Portal = false;
	Pathable = true;
}

MapTile::MapTile(char displayCharInput)
{
	displayChar = displayCharInput;
	Text = "";
	formattingCode = 7;
	Portal = false;
	if (displayChar == ' ')
	{
		Pathable = true;
	}
	else
	{
		Pathable = false;
	}
}

MapTile::MapTile(char displayCharInput, int formattingCodeInput) :MapTile(displayCharInput)
{
	formattingCode = formattingCodeInput;
	
}

MapTile::MapTile(char displayCharInput, int formattingCodeInput, bool PathableInput) :MapTile(displayCharInput, formattingCodeInput)
{
	displayChar = displayCharInput;
	Text = "";
	formattingCode = formattingCodeInput;
	Pathable = PathableInput;
}

char MapTile::getDisplayChar()
{
	return displayChar;
}
void MapTile::setDisplayChar(char displayCharInput)
{
	displayChar = displayCharInput;
}

int MapTile::getFormattingCode()
{
	return formattingCode;
}
void MapTile::setFormattingCode(int formattingCodeInput)
{
	formattingCode = formattingCodeInput;
}

string MapTile::getText()
{
	return Text;
}
void MapTile::setText(string TextInput)
{
	Text = TextInput;
}

bool MapTile::isPortal()
{
	return Portal;
}
void MapTile::setPortal(bool PortalInput)
{
	Portal = PortalInput;
}

bool MapTile::isPathable()
{
	return Pathable;
}
void MapTile::setPathable(bool PathableInput)
{
	Pathable = PathableInput;
}
